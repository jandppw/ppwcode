To un-install existing SQLCLRProject:

1. From Control Panel Add/Remove Software uninstall DeployProperties and YukonDeploy
2. From the users VS Addins folder delete DeployAddIn.dll and DeployAddIn.AddIn
3. From the users VS Templates\ItemTemplates\VisualBasic and Visual C# folders delete the SQLCLRProjectItems folders.
4. From the users VS Templates\ProjectTemplates\VisualBasic and Visual C# folders delete the SQLCLRProject folders.